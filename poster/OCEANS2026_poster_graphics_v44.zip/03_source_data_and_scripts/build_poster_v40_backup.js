const pptxgen = require("pptxgenjs");

const NAVY = "0B2545";
const DEEP = "13315C";
const TEAL = "1C7293";
const MINT = "34C6A8";
const CARD = "EEF3F7";
const INK = "132330";
const MUTED = "4A5C6A";
const WHITE = "FFFFFF";

const H_FONT = "Cambria";
const B_FONT = "Arial";


/* ---- half-scale output: OOXML caps slide size at 56 in, so the poster is
   authored at 36x24 in (exactly half of 72x48) and printed at 200%. ---- */
const K = 0.5;
const GEO = ["x", "y", "w", "h", "rectRadius"];
const FONT = ["fontSize", "lineSpacing", "paraSpaceAfter", "paraSpaceBefore", "indent"];
function scaleOpts(o) {
  if (o === null || typeof o !== "object") return o;
  if (Array.isArray(o)) return o.map(scaleOpts);
  const out = {};
  for (const k of Object.keys(o)) {
    const v = o[k];
    if (typeof v === "number" && (GEO.includes(k) || FONT.includes(k))) out[k] = v * K;
    else if (typeof v === "object") out[k] = scaleOpts(v);
    else out[k] = v;
  }
  return out;
}
const _slideProto = Object.getPrototypeOf;
function wrap(slide) {
  const at = slide.addText.bind(slide);
  const as = slide.addShape.bind(slide);
  const ai = slide.addImage.bind(slide);
  slide.addText = (t, o) => at(scaleOpts(t), scaleOpts(o));
  slide.addShape = (t, o) => as(t, scaleOpts(o));
  slide.addImage = (o) => ai(scaleOpts(o));
  return slide;
}

const pres = new pptxgen();
pres.defineLayout({ name: "POSTER36x24", width: 72 * K, height: 48 * K });
pres.layout = "POSTER36x24";

const s = wrap(pres.addSlide());
s.background = { color: WHITE };

/* ---------------- helpers ---------------- */

let panelNum = 0;

function card(x, y, w, h) {
  s.addShape(pres.ShapeType.roundRect, {
    x, y, w, h, rectRadius: 0.18,
    fill: { color: CARD }, line: { color: "D8E2EA", width: 1 },
  });
}

function panelHeader(x, y, w, text) {
  panelNum += 1;
  s.addShape(pres.ShapeType.ellipse, {
    x: x + 0.5, y: y + 0.5, w: 1.05, h: 1.05,
    fill: { color: TEAL }, line: { color: TEAL, width: 1 },
  });
  s.addText(String(panelNum), {
    x: x + 0.5, y: y + 0.5, w: 1.05, h: 1.05,
    align: "center", valign: "middle", margin: 0,
    fontFace: H_FONT, fontSize: 28, bold: true, color: WHITE,
  });
  s.addText(text, {
    x: x + 1.75, y: y + 0.35, w: w - 2.2, h: 1.4,
    align: "left", valign: "middle", margin: 0,
    fontFace: H_FONT, fontSize: 28, bold: true, color: NAVY,
  });
}

function body(x, y, w, h, items, size) {
  const fs = size || 25;
  const runs = items.map((t, i) => ({
    text: t,
    options: {
      bullet: { code: "25AA", indent: 22 },
      breakLine: i !== items.length - 1,
      paraSpaceAfter: 9,
    },
  }));
  s.addText(runs, {
    x: x + 0.6, y, w: w - 1.2, h,
    margin: 0, valign: "top",
    fontFace: B_FONT, fontSize: fs, color: INK, lineSpacing: fs * 1.18,
  });
}

function para(x, y, w, h, text, size, opts) {
  s.addText(text, Object.assign({
    x: x + 0.6, y, w: w - 1.2, h, margin: 0, valign: "top",
    fontFace: B_FONT, fontSize: size || 25, color: INK,
    lineSpacing: (size || 25) * 1.18,
  }, opts || {}));
}

function figBox(x, y, w, h, id, what, caption) {
  s.addShape(pres.ShapeType.rect, {
    x: x + 0.6, y, w: w - 1.2, h,
    fill: { color: WHITE },
    line: { color: TEAL, width: 2, dashType: "dash" },
  });
  s.addText(
    [
      { text: id + "\n", options: { fontSize: 26, bold: true, color: TEAL, fontFace: B_FONT } },
      { text: what, options: { fontSize: 21, color: MUTED, fontFace: B_FONT, italic: true } },
    ],
    {
      x: x + 0.9, y: y + 0.2, w: w - 1.8, h: h - 0.4,
      margin: 0, align: "center", valign: "middle", lineSpacing: 26,
    }
  );
  if (caption) {
    s.addText(caption, {
      x: x + 0.6, y: y + h + 0.12, w: w - 1.2, h: 1.1, margin: 0,
      fontFace: B_FONT, fontSize: 19, italic: true, color: MUTED, lineSpacing: 22,
    });
  }
}

/* ---------------- title block ---------------- */

s.addShape(pres.ShapeType.rect, {
  x: 0.6, y: 0.6, w: 56.0, h: 5.6, fill: { color: NAVY }, line: { color: NAVY, width: 1 },
});

s.addText(
  "Application of Foundation Model and Agile Modeling to Passive Acoustic Detection of Orcas in Monterey Bay National Marine Sanctuary",
  {
    x: 1.4, y: 0.85, w: 54.4, h: 3.1, margin: 0, valign: "middle",
    fontFace: H_FONT, fontSize: 62, bold: true, color: WHITE, lineSpacing: 70,
  }
);
s.addText(
  [
    { text: "Duane R. Edgington", options: { bold: true } },
    { text: "  and  " },
    { text: "John Ryan", options: { bold: true } },
    { text: "   ·   Monterey Bay Aquarium Research Institute (MBARI), Moss Landing, California, USA" },
  ],
  {
    x: 1.4, y: 4.05, w: 54.4, h: 0.9, margin: 0, valign: "middle",
    fontFace: B_FONT, fontSize: 30, color: WHITE,
  }
);
s.addText("IEEE OCEANS 2026 Monterey  ·  General Poster Track  ·  September 21–24, 2026", {
  x: 1.4, y: 5.0, w: 54.4, h: 0.8, margin: 0, valign: "middle",
  fontFace: B_FONT, fontSize: 24, color: MINT,
});

/* logo block, top right -- slots only; real files to be dropped in */
function logoSlot(bx, by, bw, bh, label, note) {
  s.addShape(pres.ShapeType.rect, {
    x: bx, y: by, w: bw, h: bh,
    fill: { color: WHITE }, line: { color: TEAL, width: 2, dashType: "dash" },
  });
  s.addText(
    [
      { text: label + "\n", options: { fontSize: 19, bold: true, color: TEAL } },
      { text: note, options: { fontSize: 15, color: MUTED, italic: true } },
    ],
    {
      x: bx + 0.25, y: by + 0.15, w: bw - 0.5, h: bh - 0.3, margin: 0,
      align: "center", valign: "middle", fontFace: B_FONT, lineSpacing: 19,
    }
  );
}

{
  const LX = 57.2, LW = 14.2, RX = LX + LW;   // right-hand block, clear of the title band
  const g = 0.8, cy = 3.30;                   // centre line of the block

  // Top row, right-aligned, each at its native proportions.
  // Right to left: General Poster marker, OCEANS 2026, IEEE OES.
  const gpW = 2.69, gpH = 2.10;               // 1480 x 1156
  const o26 = 2.50;                           // 1465 x 1465, square
  const oesW = 4.09, oesH = 1.90;             // 3435 x 1598
  const gpX = RX - gpW;
  const o26X = gpX - g - o26;
  const oesX = o26X - g - oesW;
  s.addImage({ path: "general_poster.png", x: gpX, y: cy - gpH / 2, w: gpW, h: gpH });
  s.addImage({ path: "Logo_O26M_hi.png",   x: o26X, y: cy - o26 / 2, w: o26, h: o26 });
  s.addImage({ path: "Logo_OES_hi.png",    x: oesX, y: cy - oesH / 2, w: oesW, h: oesH });

  // MBARI is NOT in this block: the template mandates it at the foot of the sheet,
  // immediately left of the QR code. See the footer.
}

/* ---------------- headline stat band ---------------- */

const stats = [
  ["14 days", "of confirmed orca in April\u2013May 2018:\nten from v4, four more when the loop was re-run"],
  ["95% fewer", "false alarms in a held-out month,\nfrom 17 corrective labels (6,489 \u2192 304)"],
  ["1,336 labels", "all of them in ~8\u201310 h of researchers'\ntime, total; 873 built the presented model"],
  ["0.95", "orca detection score (F1: 0 = useless,\n1 = perfect) at our chosen cutoff"],
  ["+19 points", "more of a held-out month\u2019s orca found\nwhen the loop was run again"],
];
{
  const y = 6.8, h = 4.6, gap = 0.6;
  const w = (70.8 - gap * 4) / 5;
  stats.forEach((st, i) => {
    const x = 0.6 + i * (w + gap);
    s.addShape(pres.ShapeType.roundRect, {
      x, y, w, h, rectRadius: 0.15,
      fill: { color: DEEP }, line: { color: DEEP, width: 1 },
    });
    s.addText(st[0], {
      x: x + 0.5, y: y + 0.35, w: w - 1.0, h: 2.0, margin: 0,
      align: "left", valign: "middle",
      fontFace: H_FONT, fontSize: 52, bold: true, color: MINT,
    });
    s.addText(st[1], {
      x: x + 0.5, y: y + 2.35, w: w - 1.0, h: 1.9, margin: 0,
      align: "left", valign: "top",
      fontFace: B_FONT, fontSize: 20, color: WHITE, lineSpacing: 24,
    });
  });
}

/* ---------------- column geometry ---------------- */

const GAP = 0.6;
const CW = (70.8 - GAP * 4) / 5; // 13.68 -- five columns on the 72 x 48 in sheet
const CX = [0.6, 0.6 + CW + GAP, 0.6 + 2 * (CW + GAP),
            0.6 + 3 * (CW + GAP), 0.6 + 4 * (CW + GAP)];
const TOP = 12.2;
const BOT = 46.4; // content bottom

/* ================= COLUMN 1 ================= */
let x = CX[0], y = TOP;

// 1 - the gap
let h = 6.6;
card(x, y, CW, h);
panelHeader(x, y, CW, "The gap");
body(x, y + 2.1, CW, 4.2, [
  "Monterey Bay National Marine Sanctuary hosts three killer whale ecotypes: transient (Bigg\u2019s), endangered Southern Resident, and Offshore.",
  "None are yet routinely detected and classified from passive acoustic monitoring (PAM) data.",
  "Detections are rare and manual annotation of thousands of hours is impractical, so labeled MARS training data are scarce.",
  "Goal: turn a continuous PAM archive into an ecologically useful record of orca presence \u2014 with its limits measured, not hidden.",
], 24);
y += h + GAP;

// 2 - site and data
h = 12.6;
card(x, y, CW, h);
panelHeader(x, y, CW, "A continuous listening post");
body(x, y + 2.1, CW, 2.8, [
  "MARS cabled observatory, Smooth Ridge (36\u00b042.75\u2032 N, 122\u00b011.21\u2032 W), ~30 km offshore at ~900 m depth.",
  "Ocean Sonics icListen HF omnidirectional hydrophone, 10 Hz \u2013 100 kHz, relayed to shore in real time, 24/7.",
  "Archived and public as the Pacific Ocean Sound recordings; analysis windows here span 2018\u20132026.",
], 24);
s.addImage({ path: "oceans2026_fig1_mars_observatory.jpg",
  x: x + (CW - 9.0) / 2, y: y + 5.2, w: 9.0, h: 5.92 });
para(x, y + 11.25, CW, 1.2,
  "The MARS cabled observatory; the hydrophone sits at the science node. Image: MBARI.",
  17, { color: MUTED, italic: true, lineSpacing: 20 });
y += h + GAP;

// 3 - baselines + class spectrograms
h = 10.4;
card(x, y, CW, h);
panelHeader(x, y, CW, "Off-the-shelf CNNs confuse the bay");
body(x, y + 2.1, CW, 3.0, [
  "The Google multispecies whale CNN and OrcAI (Icelandic fish-eating orcas) both produced high-confidence orca detections on MARS recordings.",
  "Both also confused orca calls with Pacific white-sided dolphin (Lagenorhynchus obliquidens) and other signals \u2014 confusion, not sensitivity, was the limiting factor.",
  "Their scores were still useful as a bootstrap, ranking candidate clips for the first round of expert labeling.",
], 23);
s.addImage({ path: "poster_fig3_class_spectrograms.png",
  x: x + 0.6, y: y + 5.3, w: CW - 1.2, h: 3.19 });
para(x, y + 8.6, CW, 1.7,
  "Mel-scale log-power spectrograms, one confirmed exemplar per class (5 s windows, v4 labels). All four share identical FFT parameters (2048-point FFT, 128 mel bands, 10 Hz\u201316 kHz) and one color scale, so brightness and detail are directly comparable. Orca and humpback song both carry tonal, harmonically stacked content in overlapping bands \u2014 which is why the classifier confuses them.",
  15, { color: MUTED, italic: true, lineSpacing: 17 });

/* ================= COLUMN 2 ================= */
x = CX[1]; y = TOP;

// 4 - method
h = 20.0;
card(x, y, CW, h);
panelHeader(x, y, CW, "Teaching a big model a new sound");
body(x, y + 2.1, CW, 6.0, [
  "Perch 2.0 is a pre-trained bioacoustics model. It turns each 5-second window into an embedding \u2014 a 1,536-number fingerprint of the sound. Similar sounds get similar fingerprints, so one labeled example retrieves others like it from the Hoplite database.",
  "The loop: search \u2192 label a handful of clips \u2192 refit a simple classifier on those fixed fingerprints (~30 s) \u2192 look at its mistakes \u2192 search again. The big model is never retrained.",
  "Enabling fix: per-window peak normalization to 0.25 before embedding \u2014 without it, quiet distant calls were unrecoverable.",
  "The classifier scores every window; higher means more orca-like. We keep scores above +1.16 rather than the software\u2019s 0.0 default, with the cutoff chosen on months the model never trained on.",
], 22);
s.addImage({ path: "oceans2026_fig2_agile_modeling_loop.png",
  x: x + 0.6, y: y + 8.3, w: CW - 1.2, h: 4.59 });
s.addImage({ path: "gradio_review_panel_crop.png",
  x: x + 0.6, y: y + 13.2, w: CW - 1.2, h: 5.09 });
para(x, y + 18.45, CW, 1.4,
  "What one turn of the loop looks like: a 5-second candidate, its spectrogram and audio, and six one-click labels \u2014 orca_call, humpback_song, dolphin_call, ship_noise, other, unlabeled. This detection was surfaced by v4 on 23 April 2018 (MARS_20180423_225912, score 2.03) and confirmed orca by ear. Reviewers also see a 30 s context view, not shown.",
  15, { color: MUTED, italic: true, lineSpacing: 17 });
y += h + GAP;

// 5 - all-class map
h = 12.6;
card(x, y, CW, h);
panelHeader(x, y, CW, "The classes separate");
s.addImage({ path: "tsne_apr2018_oct2020_apr2026_norm_dpi300.png",
  x: x + (CW - 9.6) / 2, y: y + 2.2, w: 9.6, h: 8.0 });
para(x, y + 10.3, CW, 2.1,
  "Each dot is one 5-second window, placed so that sounds the model hears as similar sit close together (t-SNE). 1,076 labeled windows, 6 classes, 3 seasons \u2014 the three the models trained on; May 2018 is held out and does not appear. The orca cluster holds across all three years, so the embeddings are separable across recording conditions and time. Where classes overlap, orca against humpback, is the same confusion the spectrogram row shows.",
  15, { color: MUTED, italic: true, lineSpacing: 17 });

/* ================= COLUMN 3 ================= */
x = CX[2]; y = TOP;

// 6 - trajectory
h = 12.8;
card(x, y, CW, h);
panelHeader(x, y, CW, "v0 \u2192 v4: five labeling waves");
body(x, y + 2.1, CW, 3.8, [
  "v0 (584 labels, 5 classes) recovers the known 13 April 2018 event; v1 (+214) adds October 2020; v2 (+50) rebalances dolphin and other.",
  "v3 adds just 17 hard negatives \u2014 the detector\u2019s own false alarms, labeled as counter-examples \u2014 and April-2026 false alarms fall 6,489 \u2192 304. Eight more corrective labels produce v4, the model built in this walkthrough.",
  "Two further experiments degraded performance and are not presented here; detail in the project repository.",
], 22);
s.addImage({ path: "oceans2026_fig3_classifier_trajectory.png",
  x: x + 0.6, y: y + 6.1, w: CW - 1.2, h: 4.99 });
para(x, y + 11.2, CW, 1.5,
  "Before v0: four of those hours \u2014 nearly half the project\u2019s total \u2014 went on hand review of April 2018 audio. Two 50-clip rounds settled orca-or-not, then three longer sessions worked 25 clips at a time to give dolphin and humpback their own classes, every humpback clip checked by John Ryan. Hence v0\u2019s 584 labels.",
  15, { color: MUTED, italic: true, lineSpacing: 17 });
y += h + GAP;

// 7 - spring 2018
h = 18.2;
card(x, y, CW, h);
panelHeader(x, y, CW, "Spring 2018 was not one encounter");
body(x, y + 2.1, CW, 8.6, [
  "Previously known: a single Bigg\u2019s orca event on 13 April 2018.",
  "Above our score cutoff, v4 also flagged 18 April (173 detections), 21 April (25) and 25 April (60). Listening to 25, 25 and 50 of those clips confirmed all 100 as orca, with no false alarms. All 58 detections on 23 and 24 April were then reviewed as well: 55 orca, two humpback, one left unlabeled.",
  "May 2018: 12 May confirmed 181/181; 13 May gives 8 confirmed orca clips on full review, and 14 and 16 May are confirmed too.",
  "Neither v4 nor orca_v10 has trained on May 2018 recordings \u2014 these are detections in a month the presented models have never seen.",
  "Ten confirmed orca days across the two months from v4 alone \u2014 sustained Bigg\u2019s presence, not one encounter.",
  "Two independent methods agree: regional news and whale-watch reports described record orca sightings that spring, and identified two pods \u2014 one Alaskan, one Californian (the CA140 matriline).",
], 23);
s.addImage({ path: "oceans2026_fig4_calendar_apr_may_2018.png",
  x: x + 0.6, y: y + 10.9, w: CW - 1.2, h: 5.13 });
para(x, y + 16.15, CW, 1.9,
  "Every day marked confirmed has been listened to. Bars show detections above the cutoff, and days differ in weight: 12 May rests on 181 reviewed clips. 13 May\u2019s single bar understates it \u2014 seven further confirmed orca clips sit below the cutoff. Ten days are confirmed under v4. The four hollow triangles are days only v10 found \u2014 2, 3, 7 and 29 May \u2014 marked rather than drawn as bars, because v4 had almost no detections there to plot. Fourteen days in all; see panel 10.",
  15, { color: MUTED, italic: true, lineSpacing: 17 });

/* ================= COLUMN 4 ================= */
x = CX[3]; y = TOP;

// 8 - by-day structure
h = 15.6;
card(x, y, CW, h);
panelHeader(x, y, CW, "Structure between encounters");
s.addImage({ path: "tsne_orca_by_day_4days_px30_pres_dpi300.png",
  x: x + 0.6, y: y + 2.2, w: CW - 1.2, h: 8.27 });
para(x, y + 10.6, CW, 2.0,
  "Zooming inside the orca cluster: 473 confirmed orca windows, colored by day. The 25 April evening encounter (purple) sits apart from the 13 April morning event (blue), and 12 May holds its own region a month later. The classes separate in the map at left \u2014 and within orca, encounters do too. Exploratory; perplexity 30.",
  15, { color: MUTED, italic: true, lineSpacing: 17 });
body(x, y + 12.8, CW, 2.6, [
  "The split holds however the map is drawn (three t-SNE settings) and is not an artifact of one recording or one passing vessel.",
  "Two pods were documented in the bay that spring; the two clusters are consistent with, not proof of, that pairing.",
  "The fingerprints behave like an instrument \u2014 they raise testable questions about who was calling.",
], 22);
y += h + GAP;

// 9 - specificity
h = 9.6;
card(x, y, CW, h);
panelHeader(x, y, CW, "Seen but not heard");
s.addImage({ path: "oceans2026_fig8_threshold_sweep_v4.png",
  x: x + 0.6, y: y + 2.3, w: CW - 1.2, h: 3.58 });
body(x, y + 6.1, CW, 3.3, [
  "Two months where orcas were seen from boats but never heard: October 2020 and April 2026.",
  "Every October 2020 detection above our cutoff was listened to, and every one was humpback \u2014 false alarms, not missed orca.",
  "Bigg\u2019s orcas are often silent while hunting, so seen-but-not-heard is a real outcome, not a broken detector. Both months now serve as a standing test that the detector stays quiet when it should.",
], 21);

/* ================= COLUMN 5 ================= */
x = CX[4]; y = TOP;

// 10 - running the loop again
h = 13.4;
card(x, y, CW, h);
panelHeader(x, y, CW, "Running the loop again");
para(x, y + 2.05, CW, 0.9,
  "One more turn of the loop, on more labels, produced a second classifier \u2014 orca_v10. May 2018 is the referee: neither it nor v4 has ever trained on that month.",
  19, { color: INK, lineSpacing: 22 });
s.addImage({ path: "oceans2026_fig10_v10_holdout.png",
  x: x + 0.6, y: y + 3.3, w: CW - 1.2, h: 3.2 });
body(x, y + 6.8, CW, 6.2, [
  "Across the 196 ear-confirmed orca windows in May, v10 scores higher than v4 on 192 of the 195 they share.",
  "Of v10\u2019s above-threshold detections not already confirmed, all 14 were reviewed by ear and all 14 were orca \u2014 no false alarms among those reviewed. May is not exhaustively labeled, so this is not a month-wide false-alarm rate.",
  "Four fell on days never previously confirmed \u2014 2, 3, 7 and 29 May. May\u2019s confirmed orca days go from four to eight, and the ten days in panel 7 become fourteen.",
  "The loop does not just produce a detector. Each turn produces a measurably better one.",
], 20);
y += h + GAP;

// 11 - measured limits
h = 9.6;
card(x, y, CW, h);
panelHeader(x, y, CW, "Measured limits");
para(x, y + 2.05, CW, 0.8,
  "Per-class scores for orca_v10, on 459 held-out windows. Each class has its own cutoff.",
  16, { color: MUTED, italic: true, lineSpacing: 19 });
s.addImage({ path: "oceans2026_fig9_per_class_f1_v4.png",
  x: x + 0.6, y: y + 3.0, w: CW - 1.2, h: 3.27 });
body(x, y + 6.5, CW, 2.9, [
  "Each class needs its own cutoff \u2014 the best values run from +0.79 to +2.31, so one global setting cannot serve them all. v10\u2019s orca cutoff of +2.31 is its own optimum, not a correction to the +1.16 used with v4 elsewhere here.",
  "Cutoffs are set on months the model did not train on, never on the month being analyzed.",
  "Whale-watch vessels arrive once orcas are sighted, so ship noise tracks orca presence \u2014 it can never be evidence of absence.",
], 19);
y += h + GAP;

// 12 - next, acknowledgements, references
h = 8.2;
card(x, y, CW, h);
panelHeader(x, y, CW, "Next");
body(x, y + 2.1, CW, 2.4, [
  "Humpback vocalization is one broad class covering song and a wide range of other calls. Separating them is the likeliest route to lifting the weakest scores here.",
  "Each of the two would then need its own score cutoff, as every class already has.",
  "Extending to the Southern Resident and Offshore ecotypes.",
], 19);
s.addText("Acknowledgements", {
  x: x + 0.6, y: y + 4.6, w: CW - 1.2, h: 0.5, margin: 0,
  fontFace: H_FONT, fontSize: 20, bold: true, color: NAVY,
});
para(x, y + 5.1, CW, 1.2,
  "MARS is operated by MBARI with support from the David and Lucile Packard Foundation. Visual sighting context from the California Killer Whale Project and Monterey Bay vessel reports.",
  15, { color: MUTED, lineSpacing: 17 });
s.addText("Selected references", {
  x: x + 0.6, y: y + 6.2, w: CW - 1.2, h: 0.5, margin: 0,
  fontFace: H_FONT, fontSize: 20, bold: true, color: NAVY,
});
para(x, y + 6.7, CW, 1.5,
  "van Merri\u00ebnboer et al. (2025) Perch 2.0, arXiv:2508.04665  \u00b7  Burns et al. (2025) Perch 2.0 transfers \u2018whale\u2019 to underwater tasks, arXiv:2512.03219  \u00b7  Google Research, perch-hoplite  \u00b7  Harvey, Allen & Harrell (2024) multispecies-whale, Kaggle  \u00b7  Bonhoeffer et al. (2026) orcAI, Mar. Mamm. Sci. 42(1) e70083, doi:10.1111/mms.70083  \u00b7  Ryan et al. (2016) OCEANS 2016 MTS/IEEE Monterey, doi:10.1109/OCEANS.2016.7761363  \u00b7  McInnes et al. (2023) Bigg\u2019s killer whale catalog, NOAA SWFSC, doi:10.25923/0q3f-1812",
  13, { color: MUTED, lineSpacing: 15 });

/* ---------------- footer ---------------- */
s.addImage({ path: "MBARI_logo_type.png",
  x: 55.9, y: 45.72, w: 4.60, h: 1.70 });
s.addShape(pres.ShapeType.rect, {
  x: 69.3, y: 45.55, w: 2.1, h: 2.1,
  fill: { color: WHITE }, line: { color: TEAL, width: 2, dashType: "dash" },
});
s.addText("QR", {
  x: 69.3, y: 45.55, w: 2.1, h: 2.1, margin: 0, align: "center", valign: "middle",
  fontFace: B_FONT, fontSize: 22, bold: true, color: TEAL,
});
s.addText([
  { text: "QR \u2192 code, figures and data\n", options: { bold: true } },
  { text: "github.com/duane-edgington/perch-hoplite" },
], {
  x: 61.4, y: 45.55, w: 7.4, h: 2.1, margin: 0, align: "right", valign: "middle",
  fontFace: B_FONT, fontSize: 18, italic: true, color: MUTED, lineSpacing: 21,
});

para(0.0, 45.7, 54.5, 2.0,
  "Duane R. Edgington  duane@mbari.org  \u00b7  John Ryan  ryjo@mbari.org  \u00b7  Monterey Bay Aquarium Research Institute, Moss Landing, California\nProject: mbari.org/project/soundscape-listening-room   |   Audio: Pacific Ocean Sound recordings (AWS Open Data Registry), MARS cabled observatory, MBNMS.",
  19, { color: MUTED, lineSpacing: 24 });

pres.writeFile({ fileName: "/home/claude/poster/OCEANS2026_orca_poster_DRAFT_v40.pptx" })
  .then(f => console.log("wrote", f));
