# OCEANS 2026 poster — figure delivery manifest

For Melissa. Every figure on draft v12, at the highest resolution available.
**Sizes are final printed inches on the 72 × 48 in poster** (the .pptx is authored at 36 × 24,
i.e. half scale — print at 200% or rebuild at ×2).

**Use the PDF wherever one exists.** PDFs are true vector: they stay sharp at any size, and
they are the safe choice if a figure gets scaled up during layout. The PNGs are 300 dpi at the
sizes below and are fine if placed at or under that size.

| Figure | Panel | Printed size (in) | Best file | Effective dpi | Notes |
|---|---|---|---|---|---|
| MARS observatory | 2 | 9.4 × 6.18 | `oceans2026_fig1_mars_observatory.jpg` | 145 | MBARI illustration, cropped to slot. See "known soft spots" |
| Agile-modeling loop | 4 | 10.2 × 3.75 | **`oceans2026_fig2_agile_modeling_loop.pdf`** | vector | PNG also supplied, 4815 × 1770 |
| All-class t-SNE | 5 | 8.2 × 6.83 | `tsne_apr2018_oct2020_apr2026_norm.png` | 155 | Repo image; no vector exists. See "known soft spots" |
| v0→v4 trajectory | 6 | 11.8 × 4.72 | **`oceans2026_fig3_classifier_trajectory.pdf`** | vector | PNG 4200 × 1680 |
| Class spectrograms | 3 | 16.05 × 4.10 | `poster_fig3_class_spectrograms.png` | 301 | Repo commit `d307d54`, plain "Frequency (Hz)" axis. Raster only — no vector version generated |
| April–May calendar | 7 | 16.05 × 6.60 | **`oceans2026_fig4_calendar_apr_may_2018.pdf`** | vector | PNG 4815 × 1980 |
| By-day t-SNE | 8 | 11.5 × 7.62 | `tsne_orca_by_day_4days_px30_pres.png` | 155 | Repo image; no vector exists. See "known soft spots" |
| Threshold sweep | 9 | 16.05 × 4.60 | **`oceans2026_fig8_threshold_sweep_v4.pdf`** | vector | PNG 4815 × 1380 |
| Per-class detection scores | 10 | 16.05 × 4.20 | **`oceans2026_fig9_per_class_f1_v4.pdf`** | vector | PNG 4815 × 1260 |

## Known soft spots — three figures below 300 dpi

Everything Claude generates is vector plus 300 dpi raster. Three figures come from elsewhere and
are softer than the rest. None is a blocker; all three are acceptable for large-format viewed at
a metre or more, but they will not hold up to close inspection the way the others will.

1. **Both t-SNE maps — 1784 × 1182 and 1270 × 1058, about 155 dpi at printed size.** The fix is
   to rerun the plotting script with `savefig(..., dpi=300)`, or save PDF, and re-drop the files.
   Same filenames, same slots, no layout change. Worth doing if there is time.
2. **MARS observatory — 1362 × 896 as cropped, about 145 dpi at 9.4 in wide.** The uncropped
   original is included as `..._UNCROPPED_original.jpg` (1362 × 1002) in case MBARI comms can
   supply a larger master; if they can, recrop from that rather than upscaling this one.
3. **Class spectrograms** are fine at 301 dpi, but raster only. If the panel ever needs to grow,
   rerun `poster_fig3_spectrograms_v5.py` with a PDF output rather than scaling the PNG.

## Extras

- `tsne_orca_by_day_april2018_px30_pres.png` — April-only variant of the by-day map. Not used on
  the poster; archived spare.
- A 5-day by-day t-SNE including 21 April exists in the repo and is **deliberately not used**.
  See the production doc, v11 entry, for the reasoning. Please do not substitute it.
- Regenerate any Claude-made figure with `python make_poster_figures.py <outdir>`; it needs
  `poster_fig4_calendar_apr_may_2018.csv` and `poster_fig8_threshold_sweep_v4.csv` alongside it.
